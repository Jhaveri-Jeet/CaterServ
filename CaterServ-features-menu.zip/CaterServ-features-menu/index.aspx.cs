﻿using System;

namespace CaterServ
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string timeValue = time.Text;

            TimeSpan timeSpan;
            if (!TimeSpan.TryParse(timeValue, out timeSpan))
            {
                Console.WriteLine("Invalid time format.");
                return;
            }

            DateTime dateTimeToday = DateTime.Today.Add(timeSpan);

            string formattedDateTime = dateTimeToday.ToString("dd/MM/yyyy hh:mm:ss tt");


            string dateString = date.Text;

            DateTime dateTime;
            if (!DateTime.TryParseExact(dateString, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out dateTime))
            {
                Console.WriteLine("Invalid date format.");
                return;
            }

            string formattedDate = dateTime.ToString("dd/MM/yyyy");


        }
    }
}